/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Avaliacao;

import java.util.List;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author Windows 10
 */
public class ConexaoVacina extends ConexaoBD{
    
    public void inserir(Vacina v){
        String sql = "insert into vacina values (?,?,?,?,?,?)";
        conectar();
        
        try {
            estado = con.prepareStatement(sql);
            estado.setInt(1,v.getId());
            estado.setString(2, v.getNome_vacina());
            estado.setString(3,v.getModelo_vacina());
            estado.setString(4, v.getDescricao());
            estado.setString(5, v.getFabricante());
            estado.setString(6, v.getData_validade());
            estado.execute();
            
            JOptionPane.showMessageDialog(null, "cadastro com sucesso");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "erro ao cadastrar");
        }finally{
            
        }
    }
    
    public void atualizar(Vacina v){
        String sql = "update vacina set nome_vacina = ?, modelo_vacina = ?, descricao = ?, fabricante = ?, data_validade = ? where id = ?";
        conectar();
        
        try {
            estado = con.prepareStatement(sql);
            estado.setInt(6,v.getId());
            estado.setString(1, v.getNome_vacina());
            estado.setString(2,v.getModelo_vacina());
            estado.setString(3, v.getDescricao());
            estado.setString(4, v.getFabricante());
            estado.setString(5, v.getData_validade());
            estado.execute();
            
            JOptionPane.showMessageDialog(null, "atualizado com sucesso");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "erro ao atualizar");
        }finally{
            
        }
    }
    
    public void remover(Vacina v){
        String sql = "delete from vacina where id = ?";
        conectar();
        
        try {
            estado = con.prepareStatement(sql);
            estado.setInt(1,v.getId());
            
            estado.execute();
            
            JOptionPane.showMessageDialog(null, "removido com sucesso");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "erro ao remover");
        }finally{
            
        }
    }
    
    public List<Vacina> listar(){
        List<Vacina> lista = new ArrayList<>();
        
        String sql = "select * from vacina";
        conectar();
        
        try {
            estado = con.prepareStatement(sql);
            ResultSet rs = estado.executeQuery();
            
            while (rs.next()) {
            Vacina v = new Vacina();
            v.setId(rs.getInt("id"));
            v.setNome_vacina(rs.getString("nome_vacina"));
            v.setModelo_vacina(rs.getString("modelo_vacina"));
            v.setDescricao(rs.getString("descricao"));
            v.setFabricante(rs.getString("fabricante"));
            v.setData_validade(rs.getString("data_validade"));
            
            lista.add(v);
            
            }
            JOptionPane.showMessageDialog(null, "lista com sucesso");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "erro ao listar");
        }finally{
            fecharconexao();
        }
        return lista;
    }
    
}
